"""Test suite for C Code Analyzer MCP Server"""
