"""Analyzer implementations"""
